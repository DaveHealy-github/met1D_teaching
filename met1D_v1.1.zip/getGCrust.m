function [G] = getGCrust(T)

G = getGTran(T) ; 
%G = getGKola(T) ; 

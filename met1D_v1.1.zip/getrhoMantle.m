%   calculate density
%
%   David healy 
%   May 2009 

function [rho] = getrhoMantle(T)

rho = 3300 ; 
 
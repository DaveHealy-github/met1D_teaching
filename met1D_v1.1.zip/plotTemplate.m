function plotTemplate(Ainit, Athick, z, zmax, axDepths) 


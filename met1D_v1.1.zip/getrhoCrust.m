%   calculate density
%
%   David healy 
%   May 2009 

function [rho] = getrhoCrust(T)

rho = 2700 ; 
 